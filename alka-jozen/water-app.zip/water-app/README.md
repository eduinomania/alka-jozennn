# Run this site on localhost

This folder is a static website (`index.html`, `admin.html`, `customers.html`,
`Managers.html`, `rider1.html` + images). It just needs to be served over
HTTP, not opened as `file://`, because the pages fetch images and use
browser features that require a real server.

## Easiest way (any OS, needs Python 3 — most computers already have it)

1. Unzip this folder anywhere.
2. **Windows:** double-click `start-server.bat`
   **Mac/Linux:** open a terminal in this folder and run `./start-server.sh`
3. Your browser should open automatically to:
   `http://localhost:8000/index.html`
4. To stop the server, go back to the terminal window and press `CTRL+C`.

## Manual way, if the script doesn't work

Open a terminal/command prompt **inside this folder** and run:

```
python -m http.server 8000
```
(on Mac/Linux it may be `python3` instead of `python`)

Then open your browser to:
```
http://localhost:8000/index.html
```

## Pages in this site
- `index.html` — landing / login page
- `customers.html` — customer-facing page (includes GCash QR payment)
- `admin.html` — admin dashboard
- `Managers.html` — managers dashboard
- `rider1.html` — rider page

## Note
- `customers.html`'s logo reference was fixed to point to `water_drop.png`
  (the uploaded file didn't have a space in the name; the HTML originally did).
- No backend/database is wired up — these are static files. If your app is
  meant to talk to Firebase, Supabase, or another backend, you'll need to add
  your config/API keys into the relevant `<script>` sections yourself.
