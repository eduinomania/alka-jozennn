#!/bin/bash
echo "Starting local server on http://localhost:8000"
echo "Press CTRL+C to stop the server."
( sleep 1 && open http://localhost:8000/index.html 2>/dev/null || xdg-open http://localhost:8000/index.html 2>/dev/null ) &
python3 -m http.server 8000
