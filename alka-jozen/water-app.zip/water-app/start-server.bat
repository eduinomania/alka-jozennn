@echo off
echo Starting local server on http://localhost:8000
echo Press CTRL+C to stop the server.
start http://localhost:8000/index.html
python -m http.server 8000
pause
